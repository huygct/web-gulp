'use strict';
(function () {
  angular.module('musicApp')
    .service('animalService', ['$http', '$q', function ($http, $q) {

      var self = this;


      self.cache = {
        gotData: false,

        animalTableOptions: {
          columnDefs: [
            {
              name: 'Name',
              key: 'name',
              className: 'name-col',
              enableSorting: true
            },
            {
              name: 'Age',
              key: 'age',
              className: 'age-col',
              enableSorting: true
            },
            {
              name: 'Action',
              className: 'action-col',
              cellTemplateUrl: 'scripts/demo/templates/animal-table-button.html'
            }
          ],

          enableCheckbox: true,

          data: [],
          //checkedAll: true,
          sortBy: 'age',
          sortReverse: false,
          querySearch: '',

          externalScope: {
            clickOnRowCallBack: function (row) {
              console.log('I click !!!!');
              var data = self.cache.animalTableOptions.data;
              // user want to checkbox on row when click on row
              for (var i = 0; i < data.length; i++ ) {
                if (data[i].id === row.id) {
                  data[i].checked = !data[i].checked;
                  self.cache.animalTableOptions.api.setMarkAll(); // use api of directive
                  return;
                }
              }
            }
          }
        }
      };

      // Check data to set value true or false for markAll
      function setMarkAll(data) {
        for (var i = 0; i < data.length; i++) {
          if (data[i].checked === false) {
            self.cache.animalTableOptions.checkedAll = false;
            return;
          }
        }
        self.cache.animalTableOptions.checkedAll = true;
      }

      self.setCheckboxOfHeader = function () {
        setMarkAll(self.cache.animalTableOptions.data);
      };

      self.getValueOfHeaderCheckbox = function () {
        return self.cache.animalTableOptions.checkedAll;
      };

      self.setCheckAllAnimals = function (checkedAll) {
        for (var i = 0; i < self.cache.animalTableOptions.data.length; i++) {
          self.cache.animalTableOptions.data[i].checked = checkedAll;
        }
      };

      self.toggleCheckedAnimal = function () {
        setMarkAll(self.cache.animalTableOptions.data);
      };

      self.getListAnimals = function () {
        var deferred = $q.defer();

        if (self.cache.gotData) {
          deferred.resolve(self.cache.animalTableOptions.data);
        } else {
          $http.get('data/animal.json')
            .success(function (response) {
              self.cache.gotData = true;
              self.cache.animalTableOptions.data = response;
              deferred.resolve(self.cache.animalTableOptions.data);
            })
            .error(function (response) {
              deferred.reject(response);
            });
        }
        return deferred.promise;
      };
    }]);
})();