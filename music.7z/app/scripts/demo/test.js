'use strict';
(function () {
  angular.module('musicApp')
    .controller('TestController', ['$scope', 'animalService', function ($scope, animalService) {
      var self = this;

      // catch event when destroy page song
      //$scope.$on('$destroy', function () {
        //animalService.cache.querySearch = animalTableOptions.querySearch;
      //});


      function getListAnimals() {
        animalService.getListAnimals()
          .then(function successCallback() {
            //animalService.cache.animalTableOptions.data = animalService.cache.animalTableOptions.data;
            self.animalTableOptions.data = animalService.cache.animalTableOptions.data;
          }, function errorCallback(result) {
            console.log('Fail to get songs' + result);
          });
      }

      self.animalTableOptions = animalService.cache.animalTableOptions;

      // set check all

      var checkedAll = false;

      self.setCheckAll = function () {
        checkedAll = !checkedAll;

        for(var i = 0; i < self.animalTableOptions.data.length; i++) {
          self.animalTableOptions.data[i].checked = checkedAll;
        }
        // use api of directive
        self.animalTableOptions.api.setMarkAll();
      };

      //self.getData = function () {
      //  getListAnimals();
      //};
      getListAnimals();
    }]);
})();
