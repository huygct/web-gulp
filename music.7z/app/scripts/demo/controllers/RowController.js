'use strict';
(function () {
  angular.module('musicApp')
    .controller('RowController', [function () {

      console.log('RowController');

      var ctrl = this;
      ctrl.showAnimal = function (row) {
        console.log(row);
      };
    }]);
})();