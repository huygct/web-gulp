'use strict';
(function () {
  angular.module('musicApp')
    .service('mainService', ['$document', '$timeout', function ($document, $timeout) {
      var self = this;

      self.data = {
        namePage: ''
      };

      // resize screen
      self.resizeScreen = function (){
        console.log('ressize' + self.data.namePage);
        var widthScreen = window.innerWidth;

        var heightBody = window.innerHeight - 384;
        var tBody = $document[0].querySelectorAll('table.super-table tbody');
        tBody[0].style.maxHeight =  heightBody + 'px';

        $timeout(function () {
          if (self.data.namePage === 'songs') {
            var nameSongs = $document[0].querySelectorAll('td.my-td.name-song');
            var artistSongs = $document[0].querySelectorAll('td.my-td.artist-song');

            if (widthScreen < 700) {
              var width = (widthScreen - 200) + 'px';
              //console.log(nameSongs.length);
              for (var i = 0; i < nameSongs.length; i++) {
                nameSongs[i].style.width = width;
                artistSongs[i].style.width = width;
              }
            }
            else {
              var wName = 35 + '%';
              var wArtist = 25 + '%';

              for (var j = 0; j < nameSongs.length; j++) {
                nameSongs[j].style.width = wName;
                artistSongs[j].style.width = wArtist;
                //artistSongs[j].style.paddingLeft = '16px';
                //actionTable[j].style.paddingLeft = '0px';
                //if (tBody[0].clientHeight > heightBody) {
                // appear scroll bar
                //artistSongs[j].style.paddingLeft = '24px';
                //actionTable[j].style.paddingLeft = '8px';
                //}
              }
            }
          } else {
            if (self.data.namePage === 'playlists') {
              var namePlaylists = $document[0].querySelectorAll('td.my-td.name-playlist');
              var descriptionPlaylists = $document[0].querySelectorAll('td.my-td.description-playlist');

              if (widthScreen < 700) {
                var widthPlaylists = (widthScreen - 200) + 'px';

                for (var ii = 0; ii < namePlaylists.length; ii++) {
                  namePlaylists[ii].style.width = widthPlaylists;
                  descriptionPlaylists[ii].style.width = widthPlaylists;
                }
              }
              else {
                var wNamePlaylists = 30 + '%';
                var wDescriptionPlaylists = 30 + '%';

                for (var jj = 0; jj < namePlaylists.length; jj++) {
                  namePlaylists[jj].style.width = wNamePlaylists;
                  descriptionPlaylists[jj].style.width = wDescriptionPlaylists;
                  //artistSongs[j].style.paddingLeft = '16px';
                  //actionTable[j].style.paddingLeft = '0px';
                  //if (tBody[0].clientHeight > heightBody) {
                  // appear scroll bar
                  //artistSongs[j].style.paddingLeft = '24px';
                  //actionTable[j].style.paddingLeft = '8px';
                  //}
                }
              }
            }
          }
        });
      };

      window.onresize = self.resizeScreen;

    }]);
})();