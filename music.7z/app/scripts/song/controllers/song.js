'use strict';

/**
 * @ngdoc function
 * @name musicApp.controller
 * @description
 * # SongController
 */
angular.module('musicApp')
  .controller('SongController', ['songService', 'playlistService', '$scope', '$mdSidenav', '$mdDialog', '$i18next', 'mainService', 'moviesPrepService',
    function (songService, playlistService, $scope, $mdSidenav, $mdDialog, $i18next, mainService, moviesPrepService) {
      var self = this;


      console.log('-------------- ', moviesPrepService);


      mainService.data.namePage = 'songs';
      //var NOT_FOUND = -1;//hoisting , declaration time < running time

      // get songs from service and some values was cached
      //function getListSong() {
      //  songService.getListSong()
      //    .then(function successCallback() {
      //    }, function errorCallback(result) {
      //      console.log('Fail to get songs' + result);
      //    }
      //  );
      //}

      // Controller for dialog deletes multiple song
      function dialogControllerForDeleteMultiple(scope, $mdDialog, title, context) {
        scope.title = title;
        scope.context = context;
        scope.closeDialog = function () {
          $mdDialog.hide();
        };
        scope.comfirmDeleteAll = function () {
          songService.deleteManySong(self.cache.songsTableOptions.data);

          self.cache.state = '';
          self.cache.tempSong = {};

          getListSong();

          self.cache.songsTableOptions.rowsChecked = [];
          $mdDialog.hide();
        };
      }

      // it is cheat about memory aria of $scope.menus :)
      $scope.childMenus = $scope.menus;
      $scope.childMenus.nameCurrentMenu = 'commonApp.menu.songs';
      $scope.childMenus.selectedMenu = 'Songs';

      self.cache = songService.cache;
      self.songsTableOptions = songService.cache.songsTableOptions;

      // select song when click row and press ctrl to choose songs
      //self.setChooseSong = function (song, $event) {
      //  console.log($event.ctrlKey);
      //  if ($event.shiftKey) {
      //
      //  } else {
      //    if ($event.ctrlKey) {
      //      // press ctrl
      //      song.checked = !song.checked;
      //    } else {
      //      for (var i = 0; i < self.songs.length; i++) {
      //        if (self.songs[i].id === song.id) {
      //          self.songs[i].checked = !song.checked;
      //        } else {
      //          self.songs[i].checked = false;
      //        }
      //      }
      //    }
      //  }
      //};

      // ----------------------------------------------------------
      self.changeStateToAdd = function () {
        self.cache.state = 'create';
      };

      self.changeStateToManage = function () {
        self.cache.state = '';
        self.cache.tempSong = {};
      };

      //-------------------------------------------------------------
      // add song
      self.addSong = function (song) {
        //var file = song.file;
        //songService.addSong(song, file);
        song.checked = false;
        if (typeof song.artist === 'undefined') {
          song.artist = 'none';
        }
        songService.addSong(song);

        self.changeStateToManage();

        getListSong();
      };

      // save song
      self.saveSong = function (song) {
        self.cache.tempSong = {};
        self.cache.state = '';
        songService.saveSong(song);

        getListSong();
      };

      // Delete songs
      self.showConfirmDeleteMultiple = function (ev) {
        // Appending dialog to document.body to cover sidenav in docs app
        var parentEl = angular.element(document.body);
        $mdDialog.show({
          parent: parentEl,
          targetEvent: ev,
          templateUrl: 'scripts/template/delete-multiple.html',
          locals: {
            title: $i18next('contentWeb.songs.deleteDialog.multiple.title'),
            context: $i18next('contentWeb.songs.deleteDialog.multiple.context')
          },
          controller: dialogControllerForDeleteMultiple
        });
      };

      // click button search
      self.setIsSearch = function () {
        self.cache.showSearch = true;
      };

      // click close 'x' in search box
      self.setIsNotSearch = function () {
        songService.cache.showSearch = false;
        songService.cache.songsTableOptions.querySearch = '';
      };

      // set value for sortType
      //self.changeSortType = function (sortType) {
      //  countSort++;
      //  if (keySorting !== sortType) {
      //    keySorting = sortType;
      //    self.sortReverse = false;
      //    countSort = 1;
      //
      //    if (countSort !== 3) {
      //      self.sortType = sortType;
      //      self.sortReverse = !self.sortReverse;
      //    } else {
      //      self.sortType = '';
      //      self.sortReverse = false;
      //      countSort = 0;
      //    }
      //  } else {
      //    if (countSort !== 3) {
      //      self.sortType = sortType;
      //      self.sortReverse = !self.sortReverse;
      //    } else {
      //      self.sortType = '';
      //      self.sortReverse = false;
      //      countSort = 0;
      //    }
      //  }
      //};

      // catch event when destroy page song
      $scope.$on('$destroy', function () {
        //console.log('scope destroy!');
      });

      //function onLangChange() {
      //  $scope.childMenus.nameCurrentMenu = $i18next('menu.songs');
      //}
      //$scope.$on('i18nextLanguageChange', onLangChange);
      //$scope.$watch('childMenus.isClickLinkHome', function () {
      //  //console.log('change home');
      //  self.markAll = false;
      //  getListSong();
      //  $scope.childMenus.isClickLinkHome = false;
      //});

      //getListSong();
    }])
;
