'use strict';
(function () {
  angular.module('musicApp')
    .controller('ButtonsRowOfSongController', ['songService', function (songService) {

      console.log('ButtonsRowOfSongController of songs');

      var ctrl = this;
      ctrl.editSong = function (row) {
        songService.changeStateToEdit(row);
      };

      ctrl.deleteOneSong = function ($event, row) {
        songService.showConfirmDeleteSingle($event, row);
      };
    }]);
})();