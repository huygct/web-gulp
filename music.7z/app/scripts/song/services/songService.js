/**
 * Created by thuynghi on 5/26/2015.
 */
'use strict';
/**
 * songService uses to read json and cached some value of page playlist
 */
(function () {

  angular.module('musicApp')
    .service('songService', ['$http', '$q', '$mdDialog', '$i18next', 'mainService', function ($http, $q, $mdDialog, $i18next, mainService) {
      var gotData = false; // mark that it read file json
      var self = this;

      self.cache = {
        showSearch: false, // use to save value showSearch of songs
        state: '', // use to save value state of songs page
        tempSong: {}, //tempSong to save value of song when add or edit song
        gotData: false,  // Check to read file json

        songsTableOptions: {
          columnDefs: [
            {name: 'contentWeb.songs.songTable.name', key: 'name', className: 'name-song', enableSorting: true},
            {name: 'contentWeb.songs.songTable.artist', key: 'artist', className: 'artist-song', enableSorting: true},
            {name: 'contentWeb.songs.songTable.actions', className: 'action-col', cellTemplateUrl: 'scripts/song/templates/songs-table-buttons.html'}
          ],
          enableCheckbox: true,
          checkedAll: false,
          rowsChecked: [],

          data: [],
          sortBy: '',
          sortReverse: false,
          querySearch: '',
          externalScope: {
            clickOnRowCallBack: function (row) {
              // user want to checkbox on row when click on row
              var data = self.cache.songsTableOptions.data;
              for (var i = 0; i < data.length; i++ ) {
                if (data[i].id === row.id) {
                  data[i].checked = !data[i].checked;
                  self.cache.songsTableOptions.api.setMarkAll(); // use api of directive
                  //self.setShowButtonDeleteMulti();
                  if (data[i].checked) {
                    self.cache.songsTableOptions.rowsChecked.push(row);
                  } else {
                    var index = findIndexOfObject(row.id, self.cache.songsTableOptions.rowsChecked);
                    self.cache.songsTableOptions.rowsChecked.splice(index, 1);
                  }
                  return;
                }
              }
            },
            startSuperTable: function () {
              mainService.resizeScreen();
            }
          }
        }
      };

      // start template pattern -------------------------------------------------------------------------------------
      var NOT_FOUND = -1;

      function findIndexOfObject(id, objects) {
        for (var i = 0; i < objects.length; i++) {
          if (objects[i].id === id) {
            return i;
          }
        }
        return NOT_FOUND;
      }

      function findSongIdx(id) {
        var songs = self.cache.songsTableOptions.data;
        for (var i = 0; i < songs.length; i++) {
          if (songs[i].id === id) {
            return i;
          }
        }
        return NOT_FOUND;
      }

      function findSongAndPerformAction(id, actionCallback) {
        var index = findSongIdx(id);

        if (index !== NOT_FOUND) {
          actionCallback(index);
        } else {
          throw new Error('Can\'t find song with id ' + id);
        }
      }

      // end template pattern -------------------------------------------------------------------------------------

      // find song By Id
      function findSongById(source, id) {
        findSongAndPerformAction(id, function actionCallback(idx) {
          return source(idx);
        });
        throw new Error('Couldn\'t find object with id: ' + id);
      }

      // Controller for dialog deletes a song
      function dialogControllerForDeleteSingle(scope, $mdDialog, song, title, context) {
        scope.song = song;
        scope.title = title;
        scope.context = context;
        scope.closeDialog = function () {
          $mdDialog.hide();
        };
        scope.comfirmDelete = function () {
          self.deleteOneSong(song.id);
          self.cache.state = '';

          var index = findIndexOfObject(song.id, self.cache.songsTableOptions.rowsChecked);
          self.cache.songsTableOptions.rowsChecked.splice(index, 1);
          $mdDialog.hide();
        };
      }

      // read file json
      self.getListSong = function () {
        var deferred = $q.defer();

        if (gotData) {
          deferred.resolve(self.cache.songsTableOptions.data);
        } else {
          $http.get('data/song.json')
            .success(function (response) {
              gotData = true;
              self.cache.songsTableOptions.data = response;
              deferred.resolve(response);
            })
            .error(function (response) {
              deferred.reject(response);
            });
        }
        return deferred.promise;
      };
      //self.getListSong();

      self.getSong = function (id) {
        return findSongById(self.cache.songsTableOptions.data, id);
      };

      self.addSong = function (song) {
        var songs = self.cache.songsTableOptions.data;
        if (songs.length !== 0) {
          song.id = songs[songs.length - 1].id + 1;
          songs.push(song);
        } else {
          song.id = 0;
          songs.push(song);
        }
      };

      self.saveSong = function (newSong) {
        findSongAndPerformAction(newSong.id, function actionCallback(idx) {
          self.cache.songsTableOptions.data[idx] = newSong;
        });
      };

      self.deleteOneSong = function (id) {
        findSongAndPerformAction(id, function actionCallback(idx) {
          self.cache.songsTableOptions.data.splice(idx, 1);
        });
      };

      // dialog for delete a song
      self.showConfirmDeleteSingle = function ($event, song) {
        // Appending dialog to document.body to cover sidenav in docs app
        var parentEl = angular.element(document.body);
        $mdDialog.show({
          parent: parentEl,
          targetEvent: $event,
          templateUrl: 'scripts/template/delete-single.html',
          locals: {
            song: song,
            title: $i18next('contentWeb.songs.deleteDialog.single.title'),
            context: $i18next('contentWeb.songs.deleteDialog.single.context')
          },
          controller: dialogControllerForDeleteSingle
        });

      };

      self.deleteManySong = function (oldSongs) {
        self.cache.songsTableOptions.data = [];
        angular.forEach(oldSongs, function (song) {
          if (song.checked === false || typeof song.checked === 'undefined') {
            self.cache.songsTableOptions.data.push(song);
          }
        });
        //console.log(songs);
      };

      self.changeStateToEdit = function (song) {
        self.cache.tempSong = angular.copy(song);
        self.cache.state = 'edit';
      };


      //oboe('data/song.json')
      //  .node('*.', function(name){
      //    console.log('the name is', name);
      //  })
      //  .done(function (things) {
      //    console.log('we got it: ', things);
      //  })
      //  .fail(function () {
      //
      //  });
      //function checkResponseMultiPart(data) {
      //  return ovDottie.getString(data,'response.translated.data.messageTranslated');
      //}
      //
      //function reFormatResponse(data){
      //  return data;
      //}
      //
      //function upgradeFile(data){
      //  var deferred = $q.defer();
      //  var result = $i18next('msg.requestFail');
      //
      //  oboe({
      //    url: ovHttp.proxy(api.migrate),
      //    method: 'PUT',
      //    body: data,
      //    headers: {'Content-Type': 'application/json'}
      //  })
      //    .done(function (data) {
      //      if (checkResponseMultiPart(data)) {
      //        deferred.notify(reFormatResponse(data));
      //      } else {
      //        deferred.reject(result);
      //      }
      //    })
      //    .fail(function () {
      //      deferred.reject(result);
      //    });
      //
      //  return deferred.promise;
      //}


      //
      //
      //
      //function doRequest(link, sendData, reqMethod, params) {
      //  if (link && link.indexOf('proxy?ip=') < 0) {
      //    link = ovHttp.proxy(link);
      //  }
      //  if (reqMethod.toUpperCase() !== 'DELETE') {
      //    return $http({
      //      method: reqMethod,
      //      url: link,
      //      params: params,
      //      data: sendData
      //    });
      //  } else {
      //    var requestData = {params: params, data: sendData, headers: {'Content-Type': 'application/json'}};
      //    return $http.delete(link, requestData);
      //  }
      //}
      //
      //function checkResponse(data) {
      //  if (data && data.status && data.status.toUpperCase() === 'SUCCESS') {
      //    if (data.response) {
      //      if (angular.isDefined(data.response.success)) {
      //        return data.response.success;
      //      }
      //      return true;
      //    }
      //  }
      //  return false;
      //}
      //
      //function getMessage(data) {
      //  if (data && data.response && data.response.translated && data.response.translated.messageTranslated) {
      //    return data.response.translated.messageTranslated;
      //  }
      //  return false;
      //}
      //
      //function handleRequest(url, data, method, params) {
      //  if (!angular.isObject(data)) {
      //    data = {};
      //  }
      //  var deferred = $q.defer(), result = $i18next('msg.requestFail');
      //  doRequest(url, angular.toJson(data), method, params)
      //    .success(function (data) {
      //      var dataRes = angular.fromJson(data);
      //
      //      if (checkResponse(dataRes)) {
      //        var getData = dataRes.response;
      //        if (angular.isArray(getData) || angular.isObject(getData)) {
      //          deferred.resolve(getData);
      //        } else {
      //          deferred.resolve(getMessage(dataRes) || ovDottie.getArray(dataRes, 'response'));
      //        }
      //      } else {
      //        deferred.reject(getMessage(dataRes) || result);
      //      }
      //    })
      //    .error(function () {
      //      deferred.reject(result);
      //    });
      //
      //  return deferred.promise;
      //}
      //
      //function getAppsDPIByFile(fileId) {
      //  var url = api.commonURL + fileId + '/appdpis';
      //  return handleRequest(url, null, avConstants.COMMON.httpGet);
      //}
      //
      //function deleteProfile(fileId, data) {
      //  var url = api.commonURL + fileId + '/applists';
      //  return handleRequest(url, data, avConstants.COMMON.httpDelete);
      //}
      //
      //function createProfile(fileId, data) {
      //  var url = api.commonURL + fileId + '/applists';
      //  return handleRequest(url, data, avConstants.COMMON.httpPost);
      //}
      //
      //function editProfile(fileId, data) {
      //  var url = api.commonURL + fileId + '/applists';
      //  return handleRequest(url, data, avConstants.COMMON.httpPut);
      //}

    }]);
})();