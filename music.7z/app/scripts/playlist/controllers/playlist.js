'use strict';

/**
 * @name musicApp
 * PlaylistController
 */
angular.module('musicApp')
  .controller('PlaylistController', ['playlistService', 'songService', 'playListExtend', 'playListChooseSongs', '$scope', '$mdDialog', '$i18next', 'mainService',
    function (playlistService, songService, playListExtend, playListChooseSongs, $scope, $mdDialog, $i18next, mainService) {

      var self = this;
      mainService.data.namePage = 'playlists';
      // click playlist on table
      //function setChoosePlaylistOnRow(playlist) {
      //  console.log(playlist);
      //
      //  self.currentPlaylist = playlist;
      //  self.beforeState = self.cache.state;
      //  self.cache.state = 'showSong';
      //}
      //
      //playlistService.cache.playlistsTableOptions.externalScope.clickOnRowCallBack = setChoosePlaylistOnRow;

      // get songs from service
      function getListSong() {
        songService.getListSong()
          .then(function successCallback(data) {
            self.songs = angular.copy(data);
            // set check of all songs is false
            for (var j = 0; j < self.songs.length; j++) {
              self.songs[j].checked = false;
            }
          }, function errorCallback(result) {
            console.log('Fail to get songs' + result);
          }
        );
      }

      // get playlist from service
      function getPlayLists() {
        playlistService.getListPlaylist('data/playlist.json')
          .then(function successCallback() {
          }, function errorCallback(result) {
            console.log('Fail to get playlist' + result);
          }
        );
      }

      // is called when starts playlist page
      function startPlaylist() {
        getPlayLists();
        getListSong();
      }

      // Deletes some playlist
      function dialogControllerForDeleteMultiple(scope, $mdDialog, title, context) {
        scope.title = title;
        scope.context = context;
        scope.closeDialog = function () {
          $mdDialog.hide();
        };
        scope.comfirmDeleteAll = function () {
          playlistService.deleteManyPlaylist(self.playlistsTableOptions.data);

          playlistService.cache.state = '';
          playlistService.cache.tempPlaylist = {}; // save for playlist service

          getPlayLists();

          self.cache.playlistsTableOptions.rowsChecked = [];
          $mdDialog.hide();
        };
      }

      // it is cheat about memory aria of $scope.menus :)
      $scope.childMenus = $scope.menus;
      $scope.childMenus.nameCurrentMenu = 'commonApp.menu.playlsits'; // set value for breadcrumb is Playlist
      $scope.childMenus.selectedMenu = 'Playlists'; // set value for breadcrumb is Playlist

      self.cache = playlistService.cache;
      self.playlistsTableOptions = playlistService.cache.playlistsTableOptions;

      self.songs = []; // Declare array songs

      // click button search
      self.setIsSearch = function () {
        playlistService.cache.showSearch = true;
      };

      // click close 'x' of button search...
      self.setIsNotSearch = function () {
        playlistService.cache.showSearch = false;
        playlistService.cache.playlistsTableOptions.querySearch = '';
      };

      // ----------------------------------------------------------
      self.changeStateToAdd = function () {
        playlistService.cache.state = 'create';
        playlistService.cache.tempPlaylist.songs = [];
      };

      self.changeStateToManage = function () {
        playlistService.cache.state = '';
        playlistService.cache.tempPlaylist = {};
      };

      self.changeStateToEdit = function (playlist) {
        playlistService.cache.state = 'edit';
        playlistService.cache.tempPlaylist = angular.copy(playlist); // save for song service
      };

      //-------------------------------------------------------------
      // Add new playlist
      self.addPlaylistByClick = function (playlist) {
        self.cache.tempPlaylist = {};

        playlist.checked = false;
        if (typeof playlist.description === 'undefined') {
          playlist.description = 'none';
        }
        playlistService.addPlaylist(playlist);

        self.changeStateToManage();

        getPlayLists();
      };

      // save playlist after finished edit
      self.savePlaylist = function (playlist) {
        playlistService.savePlaylist(playlist);

        playlistService.cache.state = '';
        playlistService.cache.tempPlaylist = {}; // save for song service

        getPlayLists();
      };

      // button back.
      self.backToState = function (nameState) {
        //console.log(nameState);
        self.cache.state = nameState;
      };

      // Show dialog delete multiple playlist
      self.showConfirmDeleteMultiple = function (event) {
        var parentEl = angular.element(document.body);
        $mdDialog.show({
          parent: parentEl,
          targetEvent: event,
          templateUrl: 'scripts/template/delete-multiple.html',
          locals: {
            title: $i18next('contentWeb.playlists.deleteDialog.multiple.title'),
            context: $i18next('contentWeb.playlists.deleteDialog.multiple.context')
          },
          controller: dialogControllerForDeleteMultiple
        });
      };

      startPlaylist();

      /**
       * Extend for playlist.js
       */
      playListExtend.decorator($scope, self);
      playListChooseSongs.decorator($scope, self);
    }])
;
