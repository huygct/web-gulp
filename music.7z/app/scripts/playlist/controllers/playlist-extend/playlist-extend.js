/**
 * Created by Nghi Tran on 6/5/2015.
 * Extend: Add songs for playlist and show toast
 */
'use strict';

(function () {

  angular.module('musicApp')
    .factory('playListExtend', ['$mdDialog', function ($mdDialog) {
      return {
        decorator: function ($scope, self) {
          /**
           * Controller of dialog set songs for playlist
           * @param scope
           * @param $mdDialog - a service of material angularJS for Dialog
           * @param songs  - Array songs of web music
           * @param playlist - playlist was selected
           */
          function dialogSetSongForPlaylist(scope, $mdDialog, songs, playlist) {
            // Check data to set value true or false for markAll
            function setMarkAll(listData) {
              for (var i = 0; i < listData.length; i++) {
                if (listData[i].check === false) {
                  return false;
                }
              }
              return true;
            }

            // calculate array songs which don't attached this playlist
            function setSongOutSidePlaylist(songs, songsInsidePlaylist) {
              var songsOutsidePlaylist = [];
              for (var i = 0; i < songs.length; i++) {
                var check = false;
                for (var j = 0; j < songsInsidePlaylist.length; j++) {
                  if (songs[i].id === songsInsidePlaylist[j].id) {
                    check = true;
                    break;
                  }
                }
                if (check === false) {
                  songsOutsidePlaylist.push(songs[i]);
                }
              }
              return songsOutsidePlaylist;
            }

            scope.songs = songs;
            // check to show or hide button add and remove
            scope.checkInsidePlaylist = true;
            scope.checkOutsidePlaylist = true;

            if (typeof playlist.songs === 'undefined') {
              scope.songsInsidePlaylist = [];
            } else {
              scope.songsInsidePlaylist = angular.copy(playlist.songs);
            }

            scope.songsOutsidePlaylist = setSongOutSidePlaylist(scope.songs, scope.songsInsidePlaylist);

            scope.closeDialog = function () {
              $mdDialog.hide();
            };

            // click checkbox of left side
            scope.clickCheckboxInsidePlaylist = function () {
              for (var i = 0; i < scope.songsInsidePlaylist.length; i++) {
                if (scope.songsInsidePlaylist[i].check === true) {
                  scope.checkInsidePlaylist = false;
                  break;
                } else {
                  scope.checkInsidePlaylist = true;
                }
              }
              scope.selectAllInsidePlaylist = setMarkAll(scope.songsInsidePlaylist);
            };

            // click checkbox of right side
            scope.clickCheckboxOutsidePlaylist = function () {
              for (var i = 0; i < scope.songsOutsidePlaylist.length; i++) {
                if (scope.songsOutsidePlaylist[i].check === true) {
                  scope.checkOutsidePlaylist = false;
                  break;
                } else {
                  scope.checkOutsidePlaylist = true;
                }
              }
              scope.selectAllOutsidePlaylist = setMarkAll(scope.songsOutsidePlaylist);
            };

            // Add songs was selected for this playlist
            scope.addSongToPlaylist = function () {
              for (var i = 0; i < scope.songsOutsidePlaylist.length; i++) {
                if (scope.songsOutsidePlaylist[i].check === true) {
                  scope.songsOutsidePlaylist[i].check = false;
                  scope.songsInsidePlaylist.push(scope.songsOutsidePlaylist[i]);
                  scope.songsOutsidePlaylist.splice(i, 1);
                  i--;
                }
              }

              scope.checkOutsidePlaylist = true;

              scope.selectAllInsidePlaylist = false;
              scope.selectAllOutsidePlaylist = false;
            };

            // Remove songs was selected
            scope.removeSongFromPlaylist = function () {
              for (var i = 0; i < scope.songsInsidePlaylist.length; i++) {
                if (scope.songsInsidePlaylist[i].check === true) {
                  scope.songsInsidePlaylist[i].check = false;
                  scope.songsOutsidePlaylist.push(scope.songsInsidePlaylist[i]);
                  scope.songsInsidePlaylist.splice(i, 1);
                  i--;
                }
              }

              scope.checkInsidePlaylist = true;

              scope.selectAllInsidePlaylist = false;
              scope.selectAllOutsidePlaylist = false;
            };

            // change select all songInsidePlaylist
            scope.changeSelectAllInsidePlaylist = function () {
              for (var i = 0; i < scope.songsInsidePlaylist.length; i++) {
                scope.songsInsidePlaylist[i].check = scope.selectAllInsidePlaylist;
              }
              scope.checkInsidePlaylist = !scope.selectAllInsidePlaylist;
            };

            // change select all songOutsidePlaylist
            scope.changeSelectAllOutsidePlaylist = function () {
              for (var i = 0; i < scope.songsOutsidePlaylist.length; i++) {
                scope.songsOutsidePlaylist[i].check = scope.selectAllOutsidePlaylist;
              }
              scope.checkOutsidePlaylist = !scope.selectAllOutsidePlaylist;
            };

            // Confirm for dialog set songs for playlist
            scope.confirmAddAndRemoveSongForPlaylist = function () {
              var listNameSongs = '';
              for (var i = 0; i < scope.songsInsidePlaylist.length; i++) {
                scope.songsInsidePlaylist[i].check = false;
                listNameSongs += scope.songsInsidePlaylist[i].name;
                if (i !== scope.songsInsidePlaylist.length - 1) {
                  listNameSongs += ', ';
                }
              }
              playlist.songs = scope.songsInsidePlaylist;
              playlist.listNameSongs = listNameSongs;

              $mdDialog.hide();
            };
          }

          // Show dialog to set songs for a playlist
          self.setSongForPlaylist = function (playlist, $event) {
            // show dialog to choose songs if width screen > 680

            var parentEl = angular.element(document.body);
            $mdDialog.show({
              parent: parentEl,
              targetEvent: $event,
              locals: {
                songs: angular.copy(self.songs),
                playlist: playlist
              },
              templateUrl: '../templates/select-song-dialog/select-songs.html',
              controller: dialogSetSongForPlaylist
            });

          };
        }
      };
    }]);

})();