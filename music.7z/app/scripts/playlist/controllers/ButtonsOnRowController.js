'use strict';
(function () {
  angular.module('musicApp')
    .controller('ButtonsRowController', ['playlistService', function (playlistService) {

      console.log('RowController of playlist');

      var ctrl = this;
      ctrl.editPlaylists = function (data) {
        playlistService.changeStateToEdit(data);
      };
      
      ctrl.deleteOnePlaylists = function ($event, data) {
        playlistService.showConfirmDeleteSingle($event, data);
      };
    }]);
})();