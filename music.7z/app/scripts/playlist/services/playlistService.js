/**
 * Created by thuynghi on 6/5/2015.
 */
'use strict';

/**
 * playlist service uses to cache some value
 * and read playlist from file json
 */
(function () {

  angular.module('musicApp')
    .service('playlistService', ['$http', '$q', '$mdDialog', '$i18next', 'mainService', function ($http, $q, $mdDialog, $i18next, mainService) {
      var self = this;

      self.cache = {
        showSearch: false, // use to save value showSearch of playlist
        state: '', // use to save value state of playlist
        tempPlaylist: {}, //tempPlaylist save value of playlist when add or edit
        gotData: false,  // Check to read file json

        playlistsTableOptions: {
          columnDefs: [
            { name: 'contentWeb.playlists.playlistTable.name', key: 'name', className: 'name-playlist', enableSorting: true },
            { name: 'contentWeb.playlists.playlistTable.description', key: 'description', className: 'description-playlist', enableSorting: true },
            { name: 'contentWeb.playlists.playlistTable.actions', className: 'action-col', cellTemplateUrl: 'scripts/playlist/templates/playlists-table-buttons.html' }
          ],
          enableCheckbox: true,
          checkedAll: false,
          rowsChecked: [],

          data: [],
          sortBy: '',
          sortReverse: false,
          querySearch: '',

          externalScope: {
            clickOnRowCallBack: function (row) {
              //console.log('I click !!!!');
              var data = self.cache.playlistsTableOptions.data;
              // user want to checkbox on row when click on row
              for (var i = 0; i < data.length; i++ ) {
                if (data[i].id === row.id) {
                  data[i].checked = !data[i].checked;
                  self.cache.playlistsTableOptions.api.setMarkAll(); // use api of directive
                  //self.setShowButtonDeleteMulti();
                  if (data[i].checked) {
                    self.cache.playlistsTableOptions.rowsChecked.push(row);
                  } else {
                    var index = findObjectById(row.id, self.cache.playlistsTableOptions.rowsChecked);
                    self.cache.playlistsTableOptions.rowsChecked.splice(index, 1);
                  }
                  return;
                }
              }
            },
            startSuperTable: function () {
              mainService.resizeScreen();
            }
          }
        }
      };

      var NOT_FOUND = -1;

      function findObjectById(id, objects) {
        for (var i = 0; i < objects.length; i++) {
          if(objects[i].id === id) {
            return i;
          }
        }
        return NOT_FOUND;
      }

      function findObjectAndPerformAction(id, objects, actionCallback) {
        var index = findObjectById(id, objects);

        if(index !== NOT_FOUND) {
          actionCallback(index);
        } else {
          throw new Error('Can\'t find object with id ' + id);
        }
      }

      function findPlaylistById(playlists, id) {
        findObjectAndPerformAction(id, playlists, function (idx) {
          return playlists[idx];
        });
      }

      // Deletes a playlist
      function dialogControllerForDeleteSingle(scope, $mdDialog, playlist, title, context) {
        scope.title = title;
        scope.context = context;
        scope.closeDialog = function () {
          $mdDialog.hide();
        };
        scope.comfirmDelete = function () {
          self.deleteOnePlaylist(playlist.id);

          self.cache.state = '';
          self.cache.tempPlaylist = {}; // save for playlist service

          //self.setShowButtonDeleteMulti(); // check status of button delete
          var index = findObjectById(playlist.id, self.cache.playlistsTableOptions.rowsChecked);
          self.cache.playlistsTableOptions.rowsChecked.splice(index, 1);
          $mdDialog.hide();
        };
      }

      // read file json
      self.getListPlaylist = function (url) {
        var deferred = $q.defer();
        if (self.cache.gotData === true) {
          deferred.resolve(self.cache.playlistsTableOptions.data);
        } else {
          $http.get(url)
            .success(function (response) {
              self.cache.gotData = true;
              self.cache.playlistsTableOptions.data = response;
              deferred.resolve(response);
            })
            .error(function (response) {
              deferred.reject(response);
            });
        }
        return deferred.promise;
      };
      // get playlist by id
      self.getPlaylist = function (_id) {
        var playlists = self.cache.playlistsTableOptions.data;
        return findPlaylistById(playlists, _id);
      };

      // add playlist
      self.addPlaylist = function (playlist) {
        var playlists = self.cache.playlistsTableOptions.data;
        if (playlists.length !== 0) {
          playlist.id = playlists[playlists.length - 1].id + 1;
          playlist.image = 'none';
          playlist.background = 'green';
          playlist.checked = false;
          playlists.push(playlist);
        } else {
          playlist.id = 0;
          playlist.image = '';
          playlist.background = '';
          playlist.checked = false;
          playlists.push(playlist);
        }
      };

      //----------------------------------------------------
      self.savePlaylist = function (newPlaylist) {
        var playlists = self.cache.playlistsTableOptions.data;
        findObjectAndPerformAction(newPlaylist.id, playlists, function (idx) {
          playlists[idx] = newPlaylist;
        });
      };

      self.deleteOnePlaylist = function (id) {
        var playlists = self.cache.playlistsTableOptions.data;
        findObjectAndPerformAction(id, playlists, function (idx) {
          playlists.splice(idx, 1);
        });
      };

      self.deleteManyPlaylist = function (oldplaylists) {
        self.cache.playlistsTableOptions.data = [];
        angular.forEach(oldplaylists, function (playlist) {
          if (playlist.checked === false || typeof playlist.checked === 'undefined') {
            self.cache.playlistsTableOptions.data.push(playlist);
          }
        });
        //console.log(playlists);
      };

      // add and remove song for playlist
      self.addAndRemoveSongForPlaylist = function (playlist, songs) {
        var playlists = self.cache.playlistsTableOptions.data;
        findObjectAndPerformAction(playlist.id, playlists, function (idx) {
          playlists[idx].songs = songs;
        });
      };

      // ----------------------------------------------------------
      self.changeStateToEdit = function (playlist) {
        self.cache.tempPlaylist = angular.copy(playlist);
        self.cache.state = 'edit';
      };
      //-------------------------------------------------------------

      // Show dialog deletes a playlist
      self.showConfirmDeleteSingle = function (event, playlist) {
        // Appending dialog to document.body to cover sidenav in docs app
        $mdDialog.show({
          targetEvent: event,
          templateUrl: 'scripts/template/delete-single.html',
          locals: {
            playlist: playlist,
            title: $i18next('contentWeb.playlists.deleteDialog.single.title'),
            context: $i18next('contentWeb.playlists.deleteDialog.single.context')
          },
          controller: dialogControllerForDeleteSingle
        });
      };
    }]);

})();