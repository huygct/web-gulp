/**
 * Created by Nghi Tran on 18/06/2015.
 *  */
'use strict';

(function () {
  angular.module('musicApp')
    .directive('resizeTable', ['$window', '$timeout', function ($window, $timeout) {
      return {
        restrict: 'A',
        scope: {
          type: '@type',
          valueDrop: '@valueDrop'
        },

        link: function (scope) {
          var w = angular.element($window);

          //console.log(w); // memory leak

          scope.getWindowDimensions = function () {
            return {
              'height': w.height(),
              'width': w.width()
            };
          };
          scope.$watch(scope.getWindowDimensions, function (newValue) {
            scope.windowHeight = newValue.height;
            scope.windowWidth = newValue.width;

            $timeout(function () {
              var heightBody = window.innerHeight - 384;
              var tBody = angular.element('table.super-table tbody');

              var nameSongs = document.querySelectorAll('td.my-td.name-song');
              var artistSongs = document.querySelectorAll('td.my-td.artist-song');
              //var actionTable = document.querySelectorAll('td.my-td.action-col');

              if (newValue.width < 700) {
                var width = (newValue.width - 200) + 'px';

                for (var i = 0; i < nameSongs.length; i++) {
                  nameSongs[i].style.width = width;
                  artistSongs[i].style.width = width;
                }
              }
              else {

                //if (scope.type === 'Song') {

                  var wName = 35 + '%';
                  var wArtist = 25 + '%';

                  for (var j = 0; j < nameSongs.length; j++) {
                    nameSongs[j].style.width = wName;
                    artistSongs[j].style.width = wArtist;
                    //artistSongs[j].style.paddingLeft = '16px';
                    //actionTable[j].style.paddingLeft = '0px';

                    if (tBody[0].clientHeight > heightBody) {
                      // appear scroll bar
                      //artistSongs[j].style.paddingLeft = '24px';
                      //actionTable[j].style.paddingLeft = '8px';
                    }
                  }
                //}
                //else {
                //  var descriptionPlist = document.querySelectorAll('.content-table.description-playlist');
                //
                //  for (var x = 0; x < descriptionPlist.length; x++) {
                //    if (tBody[0].clientHeight > heightBody) {
                //      // appear scroll bar
                //      descriptionPlist[x].style.paddingLeft = '8px';
                //      //actionTable[x].style.paddingLeft = '8px';
                //    }
                //  }
                //}
              }

              console.log('resize', heightBody, tBody);
              tBody.css('max-height', heightBody + 'px');

            });
          }, true);
          //console.log('bind this!');

          function applyChanges() {
            scope.$apply();
          }

          w.bind('resize.elmResize', applyChanges);

          scope.$on('$destroy', function () {
            w.unbind('resize.elmResize', applyChanges);
          });
        }
      };
    }]);
})();