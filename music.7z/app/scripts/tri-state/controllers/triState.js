'use strict';
(function () {
  angular.module('musicApp')
    .controller('TreeController', [function () {
      var self = this;

      self.treeCheckboxOptions = {
        checkboxMasterValue: false,
        checkboxMasterText: 'Master',

        data: [
          {
            checkboxChildValue: false,
            checkboxChildText: 'Ga',
            isCheckboxMaster: false // is checkbox master or not

          },
          {
            checkboxChildValue: false,
            checkboxChildText: 'Vit'
          },
          {
            checkboxChildValue: false,
            checkboxChildText: 'Cho'
          },
          {
            checkboxChildValue: false,
            checkboxChildText: 'Meo'
          }
        ]
      };

      var treeData =
        [
          {
            name: 'Dong Vat',
            children: [
              {
                name: 'Ga'
              },
              {
                cho: 'Cho'
              }
            ]
          },
          {
            name: 'Thuc vat',
            children: [
              {
                name: 'Cay1',
                children: [
                  {
                    name: 'Cay Xanh'
                  },
                  {
                    name: 'Cay Vang'
                  }
                ]
              },
              {
                name: 'Cay2'
              }
            ]
          }
        ];


    }]);
})();