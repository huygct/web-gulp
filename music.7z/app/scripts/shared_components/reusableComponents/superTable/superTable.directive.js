/**
 * Directive for table
 * tableOptions: {
 *    columnDefs: [] :define number columns and column's name
 *    enableCheckbox: true/false : table's type have checkbox or not checkbox
 *    data: data put into table
 *    sortBy: sort by 'name' or 'something'
 *    sortReverse: sort ascent or descent
 *    querySearch: string for search
 *    rowsChecked: array include data of row that was checked
 *    externalScope: some function for user action
 *      clickOnRowCallBack(): user get event choose on row.
 *      startSuperTable(): when start superTable
 *  }
 *
 * API of Directive:
 *  tableOptions.api {
 *    setMarkAll() : set value for checkboxAll on table's header when change checkbox on table's row
 *    changeSortBy() : change value sortBy
 *    ...
 *  }
 */
'use strict';
(function () {
  //var map = {
  //  'ngClick': ['asdasd', function(asdasd){}],
  //  'module.asd.asdasd': [],
  //  'com.tma.reusableComponents': []
  //};
  //map[key] = value;
  //var module = map[key];
  //var module = map['com.tma.reusableComponents'];

  var module = angular.module('com.tma.reusableComponents');
  module.directive('superTable', ['naturalService', function (naturalService) {

    function SuperTableController($scope) {
      var self = this;
      var NOT_FOUND = -1;

      function startSuperTableDirective() {
        if (!angular.isFunction(self.tableOptions.externalScope.clickOnRowCallBack)) {
          self.notNgClick = true;
          self.tableOptions.externalScope.clickOnRow = angular.noop;
        }
        if (angular.isFunction(self.tableOptions.externalScope.startSuperTable)) {
          self.tableOptions.externalScope.startSuperTable();
        }
      }

      // Check data to set value true or false for markAll
      function setMarkAll() {
        var data = self.tableOptions.data;
        if (data.length === 0) {
          self.tableOptions.checkedAll = false;
          return;
        }
        for (var i = 0; i < data.length; i++) {
          if (data[i].checked === false || typeof data[i].checked === 'undefined') {
            self.tableOptions.checkedAll = false;
            return;
          }
        }
        self.tableOptions.checkedAll = true;
      }

      function setValueCheckboxByCheckboxAll(checkedAll) {
        for (var i = 0; i < self.tableOptions.data.length; i++) {
          self.tableOptions.data[i].checked = checkedAll;
        }
      }

      function changeValueSortBy (sortBy) {
        self.countSort++;
        if (self.countSort !== 3) {
          self.tableOptions.sortBy = sortBy;
          self.tableOptions.sortReverse = !self.tableOptions.sortReverse;
        } else {
          self.tableOptions.sortBy = '';
          self.tableOptions.sortReverse = false;
          self.countSort = 0;
        }
      }

      function findObjectById(id, objects) {
        for (var i = 0; i < objects.length; i++) {
          if(objects[i].id === id) {
            return i;
          }
        }
        return NOT_FOUND;
      }

      // set api for user
      self.tableOptions.api = {};
      self.tableOptions.api.setMarkAll = setMarkAll;
      self.tableOptions.api.changeSortBy = changeValueSortBy;

      $scope.$watchCollection('superTableCtrl.tableOptions.data', function () {
        //console.log('$watchCollection tableOptions.data');
        setMarkAll();
      });

      self.getExternalScope = function () {
        return self.tableOptions.externalScope;
      };

      // sort array with field
      self.naturalSort = function (field) {
        return function (item) {
          return naturalService.naturalValue(item[field]);
        };
      };

      self.countSort = 0; // count to check sort type
      self.countSort = self.tableOptions.sortReverse ? 1 : 2;
      // set value for sortBy
      self.changeSortBy = function (sortBy) {
        changeValueSortBy(sortBy);
      };

      // start checkbox -----------------------------------------------------
      self.clickOnRow = function ($event, row) {
        if ($event.target.offsetParent.tagName !== 'MD-CHECKBOX' && $event.target.tagName !== 'BUTTON' &&
          $event.target.offsetParent.tagName !== 'BUTTON') { // check it is not checkbox
          self.tableOptions.externalScope.clickOnRowCallBack(row);
        }
      };

      self.clickMarkAll = function (checkAll) {
        if (checkAll) {
          self.tableOptions.rowsChecked = angular.copy(self.tableOptions.data);
        } else {
          self.tableOptions.rowsChecked = [];
        }
        setValueCheckboxByCheckboxAll(checkAll);
      };

      self.toggleChecked = function (row) {
        //console.log('click on checkbox');
        if (row.checked) {
          self.tableOptions.rowsChecked.push(row);
        } else {
          var index = findObjectById(row.id, self.tableOptions.rowsChecked);
          self.tableOptions.rowsChecked.splice(index, 1);
        }
        setMarkAll();
      };
      // end checkbox -----------------------------------------------------

      startSuperTableDirective();
    }

    SuperTableController.$inject = ['$scope'];

    function linkFn(/*$scope, element*/) {
    }

    return {
      restrict: 'EA',
      scope: {
        tableOptions: '='
      },
      templateUrl: 'scripts/shared_components/reusableComponents/superTable/template/superTable.html',
      controller: SuperTableController,
      controllerAs: 'superTableCtrl',
      bindToController: true,
      link: linkFn
    };
  }]);
})();
