/**
 * Created by thuynghi on 7/13/2015.
 */

'use strict';
(function () {
  angular.module('com.tma.reusableComponents')
    .directive('triStateCheckbox', [function () {

      function TriStateController () {

      }

      TriStateController.$inject = ['$scope'];

      function linkFn () {

      }

      return {
        restrict: 'EA',
        scope: {
          checkboxOptions: '='
        },
        templateUrl: 'scripts/shared_components/reusableComponents/triStateCheckbox/templates/triStateCheckbox.html',
        controller: TriStateController,
        controllerAs: 'triStateCtrl',
        bindToController: true,
        link: linkFn
      };
    }]);
})();