'use strict';

/**
 * @ngdoc overview
 * @name musicApp
 * @description
 * # musicApp use to manage songs and playlist
 *
 * Main module of the application.
 */

angular
  .module('musicApp', [
    'ngMessages',
    'ngMaterial',
    'ngCookies',
    'ngResource',
    'ngRoute',
    'ngSanitize',
    'ngTouch',
    'jm.i18next',
    'naturalSort',
    'com.tma.reusableComponents'
    // module A
    // module B
  ])
  .config(['$routeProvider', '$i18nextProvider', '$animateProvider', function ($routeProvider, $i18nextProvider, $animateProvider) {

    //$animateProvider.classNameFilter(/^(?:(?!ng-animate-disabled).)*$/);
    $animateProvider.classNameFilter(/ng-animate-enabled/);

    $routeProvider
      .when('/songs', {
        templateUrl: 'scripts/song/song.html',
        controller: 'SongController',
        controllerAs: 'songCtrl',
        resolve: {
          moviesPrepService: function(songService) {
            return songService.getListSong();
          }
        }
      })
      .when('/playlist', {
        templateUrl: 'scripts/playlist/playlist.html',
        controller: 'PlaylistController',
        controllerAs: 'playlistCtrl'
      })
      .when('/test', {
        templateUrl: 'scripts/demo/test.html',
        controller: 'TestController',
        controllerAs: 'testCtrl'
      })
      .when('/tree', {
        templateUrl: 'scripts/tri-state/triState.html',
        controller: 'TreeController',
        controllerAs: 'treeCtrl'
      })
      .otherwise({
        redirectTo: '/songs'
      });

    $i18nextProvider.options = {
      lng: 'en', // If not given, i18n will detect the browser language.
      fallbackLng: 'en', // Default is dev
      useCookie: false,
      useLocalStorage: false,
      resGetPath: 'language/__lng__/translation.json'
    };
  }])
;
